import { addPageBanner } from 'app/AppWrapper';
import { PageBanner } from './PageBanner';

export function initPageBanners() {
  addPageBanner(PageBanner);
}
